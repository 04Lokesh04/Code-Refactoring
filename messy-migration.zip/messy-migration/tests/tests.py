import pytest
from app import create_app

@pytest.fixture
def client():
    app = create_app()
    app.testing = True
    with app.test_client() as client:
        yield client


def test_create_user(client):
    res = client.post('/users', json={
        'name': 'Alice',
        'email': 'alice@example.com',
        'password': 'password123'
    })
    assert res.status_code in (201, 400)


def test_login(client):
    res = client.post('/login', json={
        'email': 'alice@example.com',
        'password': 'password123'
    })
    assert res.status_code in (200, 401)

def test_update_user(client):
    client.post('/users', json={'name': 'Loki', 'email': 'loki@email.com', 'password': 'password123'})
    res = client.put('/user/1', json={'name': 'Lokesh', 'email': 'lokeshs@email.com'})
    assert res.status_code == 200
    assert b'User updated' in res.data

def test_search_user(client):
    client.post('/users', json={'name': 'Jane Done', 'email': 'janedone@email.com', 'password': 'password123'})
    res = client.get('/search?name=Jane')
    assert res.status_code == 200
    assert b'Jane' in res.data