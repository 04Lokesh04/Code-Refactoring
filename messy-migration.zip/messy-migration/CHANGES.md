# CHANGES.md

## Major Issues Identified

1. Monolithic structure: All functionality was tightly coupled in a single file, making the app difficult to test and scale.
2. Lack of input validation: There were no proper checks for inputs like name, email, and password formats.
3. No automated tests: Critical functionalities like registration and login were not tested.
4. No modular separation: Business logic, routes, and database operations were mixed together.
5. Vulnerable to SQL injection (raw queries)
6. Unstructured and hard to maintain

## Changes Made

1. Refactored into a modular structure with clear separation of concerns:
   - `routes/user_routes.py` for user-related routes.
   - `services/user_service.py` for user-related services.
   - `utils.py` for password-related helpers and  for input validation functions.
   - `__init__.py` with an `app factory` pattern.
   -`test/tests.py` for testing 

2. Used Flask Blueprints to organize routes.
3. Implemented input validation (name, email, password) in a dedicated module.
4. Used `werkzeug.security` for password hashing and verification.
5. Maintained SQLite as the database using the built-in `sqlite3` module with schema initialization.
6. Added basic tests using `pytest` with Flask’s test client.

## Assumptions and Trade-offs

- Avoided using SQLAlchemy or other ORMs to keep the setup minimal.
- Did not introduce external validation libraries like Marshmallow or Pydantic.
- Focused on core functionality rather than advanced features (e.g., JWT, email verification).

## What I Would Do With More Time

- Implement token-based authentication (JWT or session management).
- Expand test coverage to include negative cases and edge scenarios.
- Add input sanitization and logging for better observability and security.
- Introduce configuration-based environment handling (e.g., dev, test, prod).
- Add API documentation using.

## AI usage

- As a developer with a background in the MERN stack, this was my first time working with Flask in a modular backend application. To understand Flask’s conventions, best practices, and ecosystem better, I used AI (ChatGPT) selectively during the development process — especially in areas unfamiliar to me, such as Blueprint architecture, and unit testing with `pytest`.


### AI Tools Used
- **ChatGPT by OpenAI**: Used primarily for architectural suggestions, refactoring guidance, and documentation help.

### where AI helped
-  Flask Structure 
- Testing 
-Offered suggestions for writing API test cases using Flask’s test client and `pytest`.

### summary 

AI was used as a supportive tool for:
- **Learning** unfamiliar Flask concepts
- **Improving code structure**
- **Accelerating testing and documentation**

All logic, architecture, and final outputs were carefully reviewed and **written by me**. AI was treated as an assistant — **not a replacement for thought or responsibility**.

- All AI-generated suggestions were **manually reviewed and customized**.

- Business rules and app-specific logic were entirely crafted and validated by Me.

- No direct AI-generated solutions were pushed without manual testing.

