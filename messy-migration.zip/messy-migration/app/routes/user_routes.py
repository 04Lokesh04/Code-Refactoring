from flask import Blueprint, request, jsonify
from app.services import user_service
from app.utils.validation_util import validate_user_creation, validate_user_login

user_bp = Blueprint('user_routes', __name__)

@user_bp.route('/', methods=['GET'])
def home():
    return jsonify({'message': 'User Management System'}), 200

@user_bp.route('/users', methods=['GET'])
def get_all_users():
    users = user_service.get_all_users_service()
    return jsonify(users), 200

@user_bp.route('/user/<user_id>', methods=['GET'])
def get_user(user_id):
    user = user_service.get_user_service(user_id)
    if user:
        return jsonify(user), 200
    return jsonify({'error': 'User not found'}), 404

@user_bp.route('/users', methods=['POST'])
def create_user():
    data = request.get_json()
    is_valid, message = validate_user_creation(data)
    if not is_valid:
        return jsonify({'error': message}), 400

    success = user_service.create_user_service(data['name'], data['email'], data['password'])
    if success:
        return jsonify({'message': 'User created successfully'}), 201
    return jsonify({'error': 'User creation failed'}), 500

@user_bp.route('/user/<user_id>', methods=['PUT'])
def update_user(user_id):
    data = request.get_json()
    name = data.get('name')
    email = data.get('email')
    if not name or not email:
        return jsonify({'error': 'Name and Email are required'}), 400
    user_service.update_user_service(user_id, name, email)
    return jsonify({'message': 'User updated'}), 200

@user_bp.route('/user/<user_id>', methods=['DELETE'])
def delete_user(user_id):
    user_service.delete_user_service(user_id)
    return jsonify({'message': f'User {user_id} deleted'}), 200

@user_bp.route('/search', methods=['GET'])
def search_users():
    name = request.args.get('name')
    if not name:
        return jsonify({'error': 'Please provide a name to search'}), 400
    users = user_service.search_user_by_name(name)
    return jsonify(users), 200

@user_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    is_valid, message = validate_user_login(data)
    if not is_valid:
        return jsonify({'error': message}), 400

    user = user_service.login_user_service(data['email'], data['password'])
    if user:
        return jsonify({'status': 'success', 'user_id': user['id']}), 200
    return jsonify({'status': 'failed'}), 401
