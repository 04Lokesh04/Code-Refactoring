# Code Refactoring

## Overview
You've inherited a legacy user management API that works but has significant issues. Your task is to refactor and improve this codebase while maintaining its functionality.

## Getting Started

### Prerequisites
- Python 3.8+ installed


## Folder Structure

messy-migration/
├── app.py
├── init_db.py
├── requirements.txt
├── routes/
│ └── user_routes.py
├── services/
│ └── user_service.py 
├── utils/
│ ├── db.py
│ ├── validators.py
│ └── auth.py
├──users.db
└── CHANGES.md

## Setup Instructions

### 1. Clone the repository
```bash
git clone <your-repo-url>
cd messy-migration
```
### 2. Create and activate a virtual environment
``` bash
python -m venv venv
# Activate on Windows
venv\Scripts\activate
```
# Install dependencies
```bash 
pip install -r requirements.txt
```
# Initialize the database
``` bash
 python init_db.py 
```

# Start the application
``` bash
 python app.py 
```

# The API will be available at http://localhost:5000

### Testing the Application
The application has these endpoints:
- `GET /` - Health check
- `GET /users` - Get all users
- `GET /user/<id>` - Get specific user
- `POST /users` - Create new user
- `PUT /user/<id>` - Update user
- `DELETE /user/<id>` - Delete user
- `GET /search?name=<name>` - Search users by name
- `POST /login` - User login

### Author
Lokesh S